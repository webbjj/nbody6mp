#!/bin/sh
rm -f fort.? INIT GPU
